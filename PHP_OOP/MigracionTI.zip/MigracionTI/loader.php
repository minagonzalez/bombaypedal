<?php

require 'Classes/User.php';
require 'Classes/Auth.php';
require 'Classes/JSONDB.php';
require 'Classes/Validate.php';

$email = "rodo@gmail.com";



