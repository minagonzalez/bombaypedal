<?php

require 'funciones.php';

logout();
