<?php

require 'DB.php';

class JSONDB extends DB
{
    public function dbConnect()
    {
        //...
    }

    public function dbEmailSearch($email)
    {
        //...
    }

    public function saveUser(User $user)
    {
        //...
    }

    public function photopath()
    {
        //...
    }

    public function idGenerate()
    {
        //
    }
}