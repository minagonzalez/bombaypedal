<?php

class Validate
{
    public static function emailValidate($email)
    {
        //...
    }

    public static function imageValidate($file)
    {
        //...
    }

    public static function passwordMatch($data)
    {
        //...
    }

    public static function termsAndConditions($data)
    {
        //...

    }

    public static function registerValidate(User $user, $data)
    {
        //..
    }

    public static function loginValidate()
    {
        //...
    }

}