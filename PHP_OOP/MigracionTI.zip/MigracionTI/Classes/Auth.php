<?php


class Auth
{
    public function __construct()
    {
        session_start();
    }

    // 1 - Login
    // 2 - Logout
    // 3 - Helper check
}